DrivingTrust Sell Page Deployment

1. Visit https://vercel.com
2. Log in (GitHub/Google)
3. Click: New Project → Import → Upload
4. Upload this ZIP file
5. Click Deploy

Your live page will appear at:
https://yourprojectname.vercel.app/

DrivingTrust — Safer C2C Car Selling
